# Voltra — Component Files

Each block from the full landing page, split into its own standalone HTML file so you can preview, edit, and import them individually in Claude Design.

| File | Block | Notes |
|---|---|---|
| `00-design-tokens.css` | Shared colors, radii, type | Import first so Claude applies one consistent system |
| `01-nav.html` | Utility bar + main nav | Search input, account, live cart badge |
| `02-hero.html` | Hero | Headline, CTAs, SVG product illustration |
| `03-categories.html` | Category grid | 6 rounded tiles with icons |
| `04-deal-band.html` | Deal of the day | Dark band, live countdown timer |
| `05-bestsellers.html` | Product grid | Filter chips + working "Add to cart" states |
| `06-builder.html` | PC Builder | Live dropdowns that recalculate the total price |
| `07-compare.html` | Spec comparison table | 3-column GPU comparison |
| `08-trust.html` | Trust badges | Shipping / warranty / returns / price match |
| `09-newsletter.html` | Email signup | Simple centered form |
| `10-footer.html` | Footer | 4-column sitemap |

## How to bring these into Claude Design

1. Go to **claude.ai/design** and start a new project.
2. Upload `00-design-tokens.css` first, or paste its contents into the prompt and say "use these as the design system tokens."
3. Upload or paste each numbered component in order, one at a time, and ask Claude to add it as a block/section.
4. Once everything's in, you can comment on individual blocks ("tighten the spacing in the product grid," "swap the accent color in the builder panel") and Claude will apply changes to just that section.

Each file is fully self-contained (inline CSS/JS) so it also renders correctly on its own if you just want to preview one block in a browser.
